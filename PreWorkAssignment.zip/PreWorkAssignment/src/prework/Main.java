package prework;

import java.util.Scanner;

public class Main {

	Scanner sc = new Scanner(System.in);

	public void checkPalindrome()  {

		int remainder, sum = 0, temp;  
		System.out.println("Enter a Number: ");
		int num = sc.nextInt();
		temp = num;    

		while(num > 0){  
			remainder = num % 10;    
			sum = ( sum * 10 ) + remainder;    
			num = num / 10;    
		}    

		if(temp == sum)    
			System.out.println("It is a Palindrome Number!!!");    
		else    
			System.out.println("Not Palindrome Number!!!");
		sc.close();
	}

	public void printPattern() {

		System.out.println("Enter a Number: ");
		int num = sc.nextInt();

		do {
			for (int innerIndex = 1 ; innerIndex <= num ; innerIndex++ ) {		
				System.out.print("* ");		
			}
			num --;
			System.out.println(" ");
		}while (num!=0);
	}

	public void checkPrimeNumber() {

		System.out.println("Enter a Number: ");
		int num = sc.nextInt();
		boolean isPrimeOrNot = true;

		for (int i = 2; i < num ; i ++) {

			if ( num % i == 0) {
				isPrimeOrNot = false;
				System.out.println("Not a Prime Number!!!");
				break;				
			}
		}
		if (isPrimeOrNot) 
		{
			System.out.println("It is a Prime Number!!!");	
		}

	}


	public void printFibonacciSeries() {

		int first = 0, second = 1;
		System.out.println("Enter a Number: ");
		int num = sc.nextInt();
		int sum = 0;
		
		System.out.println("Fibonacci Series of "+num+ " is: ");
		System.out.print(first + " " +second);
		
		for (int i = 1 ; i <= num; i ++) {
			sum = first + second;
			first = second;
			second = sum;		
			System.out.print(" " +sum);
		}
		System.out.println();
	}


	public static void main(String[] args) {

		Main obj = new Main();
		int choice;

		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("\nEnter your Choice from below: \n" + 
					"1. Find Palindrome of a Number.\n"
					+ "2. Print Pattern for a given Number.\n" + 
					"3. Check whether the Number is a  Prime number.\n"
					+ "4. Print Fibonacci series.\n" + 
					"--> Enter 0 to Exit.\n");

			System.out.println();
			choice = sc.nextInt();

			switch (choice) {
			case 0:
				choice = 0;
				break;
			case 1: {
				obj.checkPalindrome();
			}
			break;
			case 2: {
				obj.printPattern();
			}
			break;
			case 3: {
				obj.checkPrimeNumber();
			}
			break;
			case 4: {
				obj.printFibonacciSeries();
			}

			break;
			default:

				System.out.println("Invalid Choice / Enter a Valid no.\n");
			}

		} while (choice != 0);

		System.out.println("Exited Successfully!!!");
		sc.close();
	}

}
